# Alirezadns standalone modifications

Display branding in dashboard, login, subscriber portal and default portal title.
Original HyperDNS copyright notices and AGPL-3.0 license remain in LICENSE.
Native DNS, proxy, access control, API and account behavior are retained.
A GET/HEAD /alirezadns-source route distributes this corresponding source archive.
Build: CGO_ENABLED=0 go build -trimpath -o hyperdns ./cmd/hyperdns
The included builder.py documents fetching, checksums and branding changes.
Do not run patch_source again on these already branded sources.
Project: https://github.com/alirezachatgpt97-coder/alireza-dns
Original: https://github.com/IzumiRain/HyperDNS
