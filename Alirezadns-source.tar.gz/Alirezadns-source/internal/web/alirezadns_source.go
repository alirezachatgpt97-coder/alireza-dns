// SPDX-License-Identifier: AGPL-3.0-or-later
package web
import "net/http"
func serveAlirezadnsSource(w http.ResponseWriter, r *http.Request) {
 if r.Method != http.MethodGet && r.Method != http.MethodHead { w.Header().Set("Allow", "GET, HEAD"); http.Error(w,"method not allowed",http.StatusMethodNotAllowed); return }
 w.Header().Set("Content-Type", "application/gzip")
 w.Header().Set("Content-Disposition", "attachment; filename=Alirezadns-source.tar.gz")
 http.ServeFile(w,r,"/opt/hyperdns/alirezadns-source.tar.gz")
}
