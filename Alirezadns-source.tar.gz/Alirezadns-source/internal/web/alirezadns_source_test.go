package web
import ("net/http"; "net/http/httptest"; "testing")
func TestAlirezadnsSourceRejectsWrites(t *testing.T) {
 for _,method := range []string{"POST","PUT","DELETE","PATCH"} {
  w:=httptest.NewRecorder(); serveAlirezadnsSource(w,httptest.NewRequest(method,"/alirezadns-source",nil))
  if w.Code!=http.StatusMethodNotAllowed || w.Header().Get("Allow")!="GET, HEAD" {t.Fatalf("unexpected response for %s: %d",method,w.Code)}
 }
}
