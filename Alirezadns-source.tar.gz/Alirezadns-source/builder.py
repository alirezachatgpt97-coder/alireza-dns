#!/usr/bin/python3
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Build HyperDNS with display branding; preserve protocols and native handlers."""
import base64,hashlib,io,json,os,pathlib,re,shutil,subprocess,tarfile,tempfile,urllib.request,zipfile
COMMIT='4a899a90c682d14aa8fdc4506dd6efd84316956c'
SOURCE_SHA='6cab5bbecd98284ea57ad83194162c7240dc49c8145bae75bb65628c9462813b'
INITIAL='v2.2.0-beta.1'
REPO='https://github.com/alirezachatgpt97-coder/alireza-dns'
class HTTPSOnly(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,url):
  if not url.startswith('https://'):raise RuntimeError('Unencrypted redirect refused')
  return super().redirect_request(req,fp,code,msg,headers,url)
def fetch(url,limit=160*1024*1024):
 if not url.startswith('https://'):raise RuntimeError('HTTPS required')
 with urllib.request.build_opener(HTTPSOnly).open(urllib.request.Request(url,headers={'User-Agent':'Alirezadns-standalone/1.0'}),timeout=90) as r:
  data=r.read(limit+1)
  if len(data)>limit:raise RuntimeError('Download limit exceeded')
  return data
def extract(data,dest):
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
  members=t.getmembers()
  if len(members)>30000 or sum(m.size for m in members)>200*1024*1024:raise RuntimeError('Source archive too large')
  for m in members:
   p=pathlib.PurePosixPath(m.name)
   if p.is_absolute() or '..' in p.parts or not(m.isfile() or m.isdir()):raise RuntimeError('Unsafe source archive')
   target=dest.joinpath(*p.parts)
   if m.isdir():target.mkdir(parents=True,exist_ok=True)
   else:
    target.parent.mkdir(parents=True,exist_ok=True)
    with t.extractfile(m) as src,open(target,'wb') as out:shutil.copyfileobj(src,out)
    os.chmod(target,m.mode&0o755)
 roots=list(dest.iterdir())
 if len(roots)!=1 or not (roots[0]/'go.mod').exists():raise RuntimeError('Unexpected source layout')
 return roots[0]
def patch_source(root):
 if (root/'ALIREZADNS-CHANGES.md').exists():raise RuntimeError('Source already branded')
 targets=['web/index.html','web/login.html','web/js/app.js','web/js/i18n.js','web/js/portal.js','internal/web/portal.go','internal/web/portal_i18n.go','internal/database/subscription_access.go']
 for name in targets:
  p=root/name
  if not p.exists():raise RuntimeError('Upstream UI layout changed: '+name)
  text=p.read_text(encoding='utf-8');text=re.sub(r'HyperDNS|HyperRAIN|HyperSHIELD','Alirezadns',text)
  if name.endswith('.html') or name=='internal/web/portal.go':
   text=text.replace('</body>','<footer style="text-align:center;padding:8px;font-size:12px"><a href="/alirezadns-source">Alirezadns source · AGPL-3.0 · Based on HyperDNS</a></footer>\n</body>')
  p.write_text(text,encoding='utf-8',newline='\n')
 # A narrow public source-download route, never a directory server.
 p=root/'internal/web/server.go';s=p.read_text(encoding='utf-8');needle='\t\tp := cleanRequestPath(r.URL.Path)'
 if needle not in s:raise RuntimeError('Upstream routing changed; integration review required')
 if s.count(needle)!=3:raise RuntimeError('Upstream public surfaces changed; integration review required')
 s=s.replace(needle,needle+'\n\t\tif p == "/alirezadns-source" { serveAlirezadnsSource(w, r); return }');p.write_text(s,encoding='utf-8',newline='\n')
 (root/'internal/web/alirezadns_source.go').write_text('''// SPDX-License-Identifier: AGPL-3.0-or-later
package web
import "net/http"
func serveAlirezadnsSource(w http.ResponseWriter, r *http.Request) {
 if r.Method != http.MethodGet && r.Method != http.MethodHead { w.Header().Set("Allow", "GET, HEAD"); http.Error(w,"method not allowed",http.StatusMethodNotAllowed); return }
 w.Header().Set("Content-Type", "application/gzip")
 w.Header().Set("Content-Disposition", "attachment; filename=Alirezadns-source.tar.gz")
 http.ServeFile(w,r,"/opt/hyperdns/alirezadns-source.tar.gz")
}
''',encoding='utf-8')
 # Update only branding expectations; retain the original behavioral assertions.
 for name in ['document_structure_test.go','login_page_test.go','subscription_test.go']:
  p=root/'internal/web'/name;p.write_text(p.read_text(encoding='utf-8').replace('HyperDNS','Alirezadns'),encoding='utf-8',newline='\n')
 p=root/'internal/web/method_allow_test.go';s=p.read_text(encoding='utf-8');needle='var allowSourceFiles = []string{'
 if needle not in s:raise RuntimeError('Upstream method checks changed')
 p.write_text(s.replace(needle,needle+'"alirezadns_source.go", ',1),encoding='utf-8',newline='\n')
 (root/'internal/web/alirezadns_source_test.go').write_text('''package web
import ("net/http"; "net/http/httptest"; "testing")
func TestAlirezadnsSourceRejectsWrites(t *testing.T) {
 for _,method := range []string{"POST","PUT","DELETE","PATCH"} {
  w:=httptest.NewRecorder(); serveAlirezadnsSource(w,httptest.NewRequest(method,"/alirezadns-source",nil))
  if w.Code!=http.StatusMethodNotAllowed || w.Header().Get("Allow")!="GET, HEAD" {t.Fatalf("unexpected response for %s: %d",method,w.Code)}
 }
}
''',encoding='utf-8')
 p=root/'version.json';v=json.loads(p.read_text());v['homepage']=REPO;v['codename']='Alirezadns';p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
 (root/'ALIREZADNS-CHANGES.md').write_text('''# Alirezadns standalone modifications

Display branding in dashboard, login, subscriber portal and default portal title.
Original HyperDNS copyright notices and AGPL-3.0 license remain in LICENSE.
Native DNS, proxy, access control, API and account behavior are retained.
A GET/HEAD /alirezadns-source route distributes this corresponding source archive.
Build: CGO_ENABLED=0 go build -trimpath -o hyperdns ./cmd/hyperdns
The included builder.py documents fetching, checksums and branding changes.
Do not run patch_source again on these already branded sources.
Project: '''+REPO+'\nOriginal: https://github.com/IzumiRain/HyperDNS\n',encoding='utf-8')
def toolchain(agent,arch):
 version='v0.0.1-go1.26.4.linux-'+arch;module='golang.org/toolchain';target=agent/('go1.26.4-'+arch)
 if (target/'bin/go').is_file():return target/'bin/go'
 data=fetch('https://proxy.golang.org/'+module+'/@v/'+version+'.zip')
 lookup=fetch('https://sum.golang.org/lookup/'+module+'@'+version,65536).decode()
 matches=[line.split()[2] for line in lookup.splitlines() if line.startswith(module+' '+version+' ')]
 if len(matches)!=1:raise RuntimeError('Toolchain checksum unavailable')
 with zipfile.ZipFile(io.BytesIO(data)) as z:
  names=sorted(n for n in z.namelist() if not n.endswith('/'))
  if sum(i.file_size for i in z.infolist())>500*1024*1024:raise RuntimeError('Toolchain too large')
  digest=hashlib.sha256()
  for n in names:digest.update((hashlib.sha256(z.read(n)).hexdigest()+'  '+n+'\n').encode())
  if 'h1:'+base64.b64encode(digest.digest()).decode()!=matches[0]:raise RuntimeError('Official Go module checksum mismatch')
  stage=pathlib.Path(tempfile.mkdtemp(prefix='go-stage-',dir=agent))
  try:
   prefix=module+'@'+version+'/'
   for n in names:
    if not n.startswith(prefix):raise RuntimeError('Invalid toolchain path')
    relative=pathlib.PurePosixPath(n[len(prefix):])
    if relative.is_absolute() or '..' in relative.parts:raise RuntimeError('Unsafe toolchain path')
    p=stage.joinpath(*relative.parts);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n));os.chmod(p,0o755 if n.startswith(prefix+'bin/') or n.startswith(prefix+'pkg/tool/') else 0o644)
   os.replace(stage,target)
  finally:
   if stage.exists():shutil.rmtree(stage)
 return target/'bin/go'
def build(version,arch,agent):
 agent=pathlib.Path(agent);agent.mkdir(parents=True,exist_ok=True,mode=0o700)
 if not re.fullmatch(r'v2\.\d+\.\d+(?:-[A-Za-z0-9.]+)?',version):raise RuntimeError('Unsupported upstream release')
 ref=COMMIT if version==INITIAL else version
 data=fetch('https://codeload.github.com/IzumiRain/HyperDNS/tar.gz/'+ref,32*1024*1024)
 digest=hashlib.sha256(data).hexdigest()
 if version==INITIAL and digest!=SOURCE_SHA:raise RuntimeError('Pinned source checksum mismatch')
 with tempfile.TemporaryDirectory(prefix='build-',dir=agent) as tmp:
  root=extract(data,pathlib.Path(tmp));patch_source(root);shutil.copy2(__file__,root/'builder.py')
  (root/'ALIREZADNS-UPSTREAM.json').write_text(json.dumps({'ref':ref,'sha256':digest,'version':version}))
  go=toolchain(agent,arch)
  env={**os.environ,'CGO_ENABLED':'0','GOMAXPROCS':'1','GOGC':'30','GOTOOLCHAIN':'auto','GOPROXY':'https://proxy.golang.org','GOSUMDB':'sum.golang.org','GOPATH':str(agent/'go-cache'),'GOCACHE':str(agent/'build-cache'),'GOROOT':str(go.parent.parent)}
  output=pathlib.Path(tmp)/'built-hyperdns'
  subprocess.run([str(go),'build','-p','1','-trimpath','-o',str(output),'./cmd/hyperdns'],cwd=root,env=env,check=True,timeout=3600)
  with tarfile.open(agent/'candidate-source.tar.gz','w:gz') as archive:archive.add(root,arcname='Alirezadns-source')
  return output.read_bytes()
